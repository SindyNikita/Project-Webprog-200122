<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class snack extends Model
{
    public $timestamps = false;
    use HasFactory;
    public function getAllData()
    {
        return $this
            ->leftJoin('details', 'produk.id', '=', 'details.produk_id')
            ->select('*')
            ->get();
    }
    public function getSelectedBook($id)
    {
        return $this
            ->leftJoin('details', 'produk.id', '=', 'details.produk_id')
            ->select('*')
            ->where('produk.id','=',$id)
            ->get()->first();
    }
}
