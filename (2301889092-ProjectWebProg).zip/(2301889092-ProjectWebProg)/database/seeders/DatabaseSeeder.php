<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Book;
use App\Models\Detail;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        //Category
        Category::create([
            'category' => 'Candy'
        ]);
        Category::create([
            'category' => 'Chocolate'
        ]);
        Category::create([
            'category' => 'Chips'
        ]);
        Category::create([
            'category' => 'Cereal'
        ]);

        //Snack
        Snack::create([
            'category_id' => rand(1,4),
            'nama_produk' => "Gum Bear"
        ]);
        Snack::create([
            'category_id' => rand(1,4),
            'nama_produk' => "Gold Queen"
        ]);
        Snack::create([
            'category_id' => rand(1,4),
            'nama_produk' => "Doratos"
        ]);
        Snack::create([
            'category_id' => rand(1,4),
            'nama_produk' => "Coco Crunz"
        ]);

        //Details
        Detail::create([
            'produk_id' => 1,
            'komposisi' => "Sirup glukosa, gula, air, penstabil, pemanis alami sorbitol, 
            pengatur keasaman (asam sitrat, asam laktat), protein susu, pelapis (malam, 
            lilin karnauba), konsentrat buah apel, perisa sintetik stroberi, nanas, apel,
            krim, pewarna karmin CI75470, klorofil dan klorofilin tembaga kompleks CI75815, 
            kurkumin CI75300, beta karoten CI75130.",
            'produsen' => "PT. YUPI INDO JELLY GUM",
            'produksi' => 2020,
            'description' => "Sajian per kemasan : 1"
        ]);
        Detail::create([
            'produk_id' => 2,
            'komposisi' => "Gula, susu bubuk, kacang mente, 
            kakao massa, lemak kakao, lemak nabati, pengemulsi 
            lesitin kedelai PGPR, garam, perisa vanili, antioksidan BHT",
            'produsen' => "PT. Petra Food",
            'produksi' => 2021,
            'description' => "Sajian per kemasan : 3-5"
        ]);
        Detail::create([
            'produk_id' => 3,
            'komposisi' => "Jagung, bumbu rasa keju, mengandung penguat rasa 
            mononatrium glutamat, dinatrium inosinat, dinatrium guanilat, 
            antioksidan asam askorbat, bubuk keju 4%, minyak kelapa sawit.",
            'produsen' => "PT. Indofood Fritolay Makmur",
            'produksi' => 2021,
            'description' => "Sajian per kemasan : 8"
        ]);
        Detail::create([
            'produk_id' => 4,
            'komposisi' => "Serealia 55% (Tepung Gandum Utuh, Tepung Gandum, 
            Semolina Jagung, Tepung Beras), Gula, Sari Malt (Barli), Bubuk Kakao, 
            Minyak Nabati, 2 Mineral, Susu Bubuk, Lemak Kakao, Garam  Beryodium, 
            Pengemulsi Lesitin Kedelai, Perisa Artifisial, Premiks Vitamin dan 
            Antioksidan Tokoferol.",
            'produsen' => "PT. Jaya Utama Santikah",
            'produksi' => 2020,
            'description' => "Sajian per kemasan : 6"
        ]);
    }
}
