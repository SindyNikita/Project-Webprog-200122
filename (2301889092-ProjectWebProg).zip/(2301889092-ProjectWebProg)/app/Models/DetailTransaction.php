<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetailTransaction extends Model
{
    use HasFactory;
    public function user()
    {
        return $this->belongsTo(snack::class, 'snack_id', 'snack_id');
    }
    public function transactionheader()
    {
        return $this->belongsTo(transactionheader::class, 'transaction_id', 'transaction_id');
    }
}
